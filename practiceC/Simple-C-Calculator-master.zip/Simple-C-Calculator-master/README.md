This simply works by taking three user inputs grouped into one scanf() function.
These are seperated into valueOne, valueTwo and the operator (choice of *,/,+,-,^).
A switch statement is then used in order to run the right calculation for the given operator.
Mess around with the code and change bits here and there.